<?php return array (
  'access' => 
  array (
    'captcha' => 
    array (
      'registration' => true,
    ),
    'registration' => true,
    'table_names' => 
    array (
      'password_histories' => 'password_histories',
      'users' => 'users',
    ),
    'users' => 
    array (
      'confirm_email' => true,
      'redeem_email' => false,
      'change_email' => false,
      'super_admin_role' => 'super_administrator',
      'admin_role' => 'administrator',
      'executive_role' => 'executive',
      'default_role' => 'panelist',
      'requires_approval' => false,
      'username' => 'email',
      'single_login' => true,
      'password_expires_days' => '365',
      'password_history' => '1',
      'panellist_permissions' => 
      array (
        0 => 'read profiler',
        1 => 'update profiler',
        2 => 'read reward points',
        3 => 'update reward points',
        4 => 'read redeem points',
        5 => 'update redeem points',
        6 => 'read surveys',
        7 => 'read invites',
        8 => 'update invites',
      ),
      'executive_permissions' => 
      array (
        0 => 'view backend',
        1 => 'read global settings',
      ),
      'admin_permissions' => 
      array (
        0 => 'access user management',
      ),
    ),
    'roles' => 
    array (
      'role_must_contain_permission' => true,
    ),
    'socialite_session_name' => 'socialite_provider',
    'registration_geo_ip_check' => true,
    'basic_details_zip_country_check' => true,
  ),
  'analytics' => 
  array (
    'google-analytics' => 'UA-123538092-1',
  ),
  'app' => 
  array (
    'name' => 'SJ PANEL',
    'env' => 'test3',
    'debug' => false,
    'debug_blacklist' => 
    array (
      '_COOKIE' => 
      array (
      ),
      '_SERVER' => 
      array (
      ),
      '_ENV' => 
      array (
      ),
    ),
    'url' => 'https://test3.sjpanel.com',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en_US',
    'fallback_locale' => 'en_US',
    'faker_locale' => 'en_US',
    'points' => 
    array (
      'achievement' => 
      array (
        'user_joining' => false,
        'user_confirm' => false,
        'basic_details_filled' => true,
        'profile_pic_upload' => true,
      ),
      'metric' => 
      array (
        'threshold_points' => '2000',
        'conversion' => '0.01',
      ),
    ),
    'vvars' => 
    array (
      'user_id' => 'sjpid',
      'checksum' => 'hash',
    ),
    'update_time_threshold' => 
    array (
      'hours' => 48,
    ),
    'locale_php' => 'en_US',
    'key' => 'base64:d1HKdF14YrmucEuBrJ1A37NgsRdrasGdu1v9R1RNgsQ=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\BladeServiceProvider',
      25 => 'App\\Providers\\ComposerServiceProvider',
      26 => 'App\\Providers\\EventServiceProvider',
      27 => 'App\\Providers\\ObserverServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Active' => 'HieuLe\\Active\\Facades\\Active',
      'Gravatar' => 'Creativeorange\\Gravatar\\Facades\\Gravatar',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
      'Google2FA' => 'PragmaRX\\Google2FALaravel\\Facade',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Auth\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'backend' => 
  array (
    'body_classes' => 'app header-fixed sidebar-fixed aside-menu-off-canvas sidebar-lg-show',
  ),
  'breadcrumbs' => 
  array (
    'view' => 'backend.includes.partials.breadcrumbs',
    'files' => '/var/www/html/ramesh/sjpanel.com/public_html/routes/breadcrumbs.php',
    'unnamed-route-exception' => true,
    'missing-route-bound-breadcrumb-exception' => true,
    'invalid-named-breadcrumb-exception' => true,
    'manager-class' => 'DaveJamesMiller\\Breadcrumbs\\BreadcrumbsManager',
    'generator-class' => 'DaveJamesMiller\\Breadcrumbs\\BreadcrumbsGenerator',
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'encrypted' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'redis',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'sj_panel_cache',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'mongodb_primary' => 'mongodb',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => '/var/www/html/ramesh/sjpanel.com/public_html/database/database.sqlite',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'sqlite_testing' => 
      array (
        'driver' => 'sqlite',
        'database' => ':memory:',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'sjpanel_live_v2',
        'username' => 'sjpanel',
        'password' => '1c298213059121',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
      ),
      'mysql_global' => 
      array (
        'driver' => 'mysql',
        'host' => '45.40.143.179',
        'port' => '3306',
        'database' => 'sjpanel_live_global',
        'username' => 'sjpanel_live_v2',
        'password' => '-eOG!MuZEGP&',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
      ),
      'mongodb' => 
      array (
        'driver' => 'mongodb',
        'host' => '143.244.161.22',
        'port' => '27017',
        'database' => 'sjpaneldb',
        'username' => 'Sjpanel_Admin',
        'password' => 'KX2w2d4a12342xce2',
        'options' => 
        array (
          'database' => 'admin',
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '5432',
        'database' => 'forge',
        'username' => 'forge',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => 'localhost',
        'port' => '1433',
        'database' => 'forge',
        'username' => 'forge',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => 'localhost',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => false,
    'except' => 
    array (
      0 => 'telescope*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/debugbar',
      'connection' => NULL,
      'provider' => '',
    ),
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => true,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'timeline' => false,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => true,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/app/public',
        'url' => 'https://test3.sjpanel.com/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
      ),
    ),
  ),
  'geoip' => 
  array (
    'log_failures' => true,
    'include_currency' => true,
    'service' => 'ipapi',
    'services' => 
    array (
      'maxmind_database' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\MaxMindDatabase',
        'database_path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/app/geoip.mmdb',
        'update_url' => 'https://geolite.maxmind.com/download/geoip/database/GeoLite2-City.mmdb.gz',
        'locales' => 
        array (
          0 => 'en',
        ),
      ),
      'maxmind_api' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\MaxMindWebService',
        'user_id' => 'pankajj@samplejunction.com',
        'license_key' => 'rrXPH7JXvNhC',
        'locales' => 
        array (
          0 => 'en',
        ),
      ),
      'ipapi' => 
      array (
        'class' => 'Torann\\GeoIP\\Services\\IPApi',
        'secure' => true,
        'key' => NULL,
        'continent_path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/app/continents.json',
        'lang' => 'en',
      ),
    ),
    'cache' => 'none',
    'cache_tags' => NULL,
    'cache_expires' => 30,
    'default_location' => 
    array (
      'ip' => '127.0.0.0',
      'iso_code' => 'US',
      'country' => 'United States',
      'city' => 'New Haven',
      'state' => 'CT',
      'state_name' => 'Connecticut',
      'postal_code' => '06510',
      'lat' => 41.31,
      'lon' => -72.92,
      'timezone' => 'America/New_York',
      'continent' => 'NA',
      'default' => true,
      'currency' => 'USD',
    ),
  ),
  'google2fa' => 
  array (
    'enabled' => true,
    'lifetime' => 0.5,
    'keep_alive' => true,
    'auth' => 'auth',
    'session_var' => 'google2fa',
    'otp_input' => 'one_time_password',
    'window' => 1,
    'forbid_old_passwords' => true,
    'otp_secret_column' => 'google2fa_secret',
    'view' => 'frontend.auth.google2fa.two_fact_login',
    'error_messages' => 
    array (
      'wrong_otp' => 'The \'One Time Password\' typed was wrong.',
    ),
    'throw_exceptions' => true,
  ),
  'gravatar' => 
  array (
    'default' => 
    array (
      'size' => 80,
      'fallback' => 'mm',
      'secure' => false,
      'maximumRating' => 'g',
      'forceDefault' => false,
      'forceExtension' => 'jpg',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'laratables' => 
  array (
    'row_id_prefix' => 'laratables_row_',
    'date_format' => 'Y-m-d H:i:s',
    'non_searchable_columns' => 
    array (
    ),
    'max_limit' => 0,
  ),
  'locale' => 
  array (
    'default_country' => 'US',
    'default_language' => 'EN',
    'status' => true,
    'languages' => 
    array (
      'en_US' => 
      array (
        0 => 'en_US',
        1 => 'en_US',
        2 => false,
      ),
      'es_US' => 
      array (
        0 => 'es_US',
        1 => 'es_US',
        2 => false,
      ),
      'en_UK' => 
      array (
        0 => 'en_UK',
        1 => 'en_UK',
        2 => false,
      ),
      'es_ES' => 
      array (
        0 => 'es_US',
        1 => 'es_US',
        2 => false,
      ),
      'en_ES' => 
      array (
        0 => 'en_ES',
        1 => 'en_ES',
        2 => false,
      ),
      'en_DE' => 
      array (
        0 => 'en_DE',
        1 => 'en_DE',
        2 => false,
      ),
      'de_DE' => 
      array (
        0 => 'de_DE',
        1 => 'de_DE',
        2 => false,
      ),
      'en_IT' => 
      array (
        0 => 'en_IT',
        1 => 'en_IT',
        2 => false,
      ),
      'it_IT' => 
      array (
        0 => 'it_IT',
        1 => 'it_IT',
        2 => false,
      ),
      'en_CA' => 
      array (
        0 => 'en_CA',
        1 => 'en_CA',
        2 => false,
      ),
      'fr_CA' => 
      array (
        0 => 'fr_CA',
        1 => 'fr_CA',
        2 => false,
      ),
      'en_FR' => 
      array (
        0 => 'en_FR',
        1 => 'en_FR',
        2 => false,
      ),
      'fr_FR' => 
      array (
        0 => 'fr_FR',
        1 => 'fr_FR',
        2 => false,
      ),
      'en_IN' => 
      array (
        0 => 'en_IN',
        1 => 'en_IN',
        2 => false,
      ),
      'hi_IN' => 
      array (
        0 => 'hi_IN',
        1 => 'hi_IN',
        2 => false,
      ),
      'en_AU' => 
      array (
        0 => 'en_AU',
        1 => 'en_AU',
        2 => false,
      ),
      'en_CN' => 
      array (
        0 => 'en_CN',
        1 => 'en_CN',
        2 => false,
      ),
      'zh_CN' => 
      array (
        0 => 'zh_CN',
        1 => 'zh_CN',
        2 => false,
      ),
    ),
  ),
  'log-viewer' => 
  array (
    'storage-path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/logs',
    'pattern' => 
    array (
      'prefix' => 'laravel-',
      'date' => '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]',
      'extension' => '.log',
    ),
    'locale' => 'auto',
    'theme' => 'bootstrap-4',
    'route' => 
    array (
      'enabled' => true,
      'attributes' => 
      array (
        'prefix' => 'admin/log-viewer',
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin',
        ),
      ),
    ),
    'per-page' => 30,
    'facade' => 'LogViewer',
    'download' => 
    array (
      'prefix' => 'laravel-',
      'extension' => 'log',
    ),
    'menu' => 
    array (
      'filter-route' => 'log-viewer::logs.filter',
      'icons-enabled' => true,
    ),
    'icons' => 
    array (
      'all' => 'fa fa-fw fa-list',
      'emergency' => 'fa fa-fw fa-bug',
      'alert' => 'fa fa-fw fa-bullhorn',
      'critical' => 'fa fa-fw fa-heartbeat',
      'error' => 'fa fa-fw fa-times-circle',
      'warning' => 'fa fa-fw fa-exclamation-triangle',
      'notice' => 'fa fa-fw fa-exclamation-circle',
      'info' => 'fa fa-fw fa-info-circle',
      'debug' => 'fa fa-fw fa-life-ring',
    ),
    'colors' => 
    array (
      'levels' => 
      array (
        'empty' => '#D1D1D1',
        'all' => '#8A8A8A',
        'emergency' => '#B71C1C',
        'alert' => '#D32F2F',
        'critical' => '#F44336',
        'error' => '#FF5722',
        'warning' => '#FF9100',
        'notice' => '#4CAF50',
        'info' => '#1976D2',
        'debug' => '#90CAF9',
      ),
    ),
    'highlight' => 
    array (
      0 => '^#\\d+',
      1 => '^Stack trace:',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
          1 => 'teams',
        ),
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'teams' => 
      array (
        'driver' => 'custom',
        'via' => 'SampleJunction\\LaravelLoggerForTeams\\LoggerChannel',
        'level' => 'debug',
        'url' => 'https://outlook.office.com/webhook/8cc08659-8d48-4b7a-aa56-e3721a2e079a@e24e70de-a391-4c09-9140-90bcdfc15f42/IncomingWebhook/bf2597e63b3846fab89aefcc26624a25/f8f01fb5-2bbb-41a2-b526-982c3a299a02',
        'style' => 'card',
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'SJ Panel - Logger',
        'emoji' => ':robot_face:',
        'level' => 'debug',
      ),
      'slack-monitor' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'SJ Panel Monitor BOT',
        'emoji' => ':robot_face:',
        'level' => 'debug',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'mailgun',
    'host' => 'smtp.mailgun.org',
    'port' => '587',
    'from' => 
    array (
      'address' => 'no-reply@mg.sjpanel.com',
      'name' => 'SJ Panel',
    ),
    'to' => 
    array (
      'address' => 'muneshk@samplejunction.com',
      'name' => 'Munesh',
    ),
    'encryption' => 'tls',
    'username' => 'postmaster@mg.sjpanel.com',
    'password' => '799a9875103c67ac4a0019ca69296115-30b9cd6d-dcecd56f',
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/var/www/html/ramesh/sjpanel.com/public_html/resources/views/vendor/mail',
      ),
    ),
    'log_channel' => NULL,
  ),
  'no-captcha' => 
  array (
    'secret' => '6LeE4WcUAAAAADL-SxF_TgHSmrqX8DT3jQaZJR2R',
    'sitekey' => '6LeE4WcUAAAAAMl1qUUqda_zkrUth6mHpjsJPFPx',
    'lang' => 'en_US',
    'attributes' => 
    array (
      'data-theme' => NULL,
      'data-type' => NULL,
      'data-size' => NULL,
    ),
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'model_morph_key' => 'model_id',
    ),
    'display_permission_in_exception' => false,
    'cache' => 
    array (
      'expiration_time' => 
      DateInterval::__set_state(array(
         'y' => 0,
         'm' => 0,
         'd' => 0,
         'h' => 24,
         'i' => 0,
         's' => 0,
         'f' => 0.0,
         'weekday' => 0,
         'weekday_behavior' => 0,
         'first_last_day_of' => 0,
         'invert' => 0,
         'days' => false,
         'special_type' => 0,
         'special_amount' => 0,
         'have_weekday_relative' => 0,
         'have_special_relative' => 0,
      )),
      'key' => 'spatie.permission.cache',
      'model_key' => 'name',
      'store' => 'default',
    ),
    'cache_expiration_time' => 1440,
    'log_registration_exception' => true,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'self-diagnosis' => 
  array (
    'environment_aliases' => 
    array (
      'prod' => 'production',
      'live' => 'production',
      'local' => 'development',
    ),
    'checks' => 
    array (
      0 => 'BeyondCode\\SelfDiagnosis\\Checks\\AppKeyIsSet',
      1 => 'BeyondCode\\SelfDiagnosis\\Checks\\CorrectPhpVersionIsInstalled',
      'BeyondCode\\SelfDiagnosis\\Checks\\DatabaseCanBeAccessed' => 
      array (
        'default_connection' => true,
        'connections' => 
        array (
        ),
      ),
      'BeyondCode\\SelfDiagnosis\\Checks\\DirectoriesHaveCorrectPermissions' => 
      array (
        'directories' => 
        array (
          0 => '/var/www/html/ramesh/sjpanel.com/public_html/storage',
          1 => '/var/www/html/ramesh/sjpanel.com/public_html/bootstrap/cache',
        ),
      ),
      2 => 'BeyondCode\\SelfDiagnosis\\Checks\\EnvFileExists',
      3 => 'BeyondCode\\SelfDiagnosis\\Checks\\ExampleEnvironmentVariablesAreSet',
      4 => 'BeyondCode\\SelfDiagnosis\\Checks\\MigrationsAreUpToDate',
      'BeyondCode\\SelfDiagnosis\\Checks\\PhpExtensionsAreInstalled' => 
      array (
        'extensions' => 
        array (
          0 => 'openssl',
          1 => 'PDO',
          2 => 'mbstring',
          3 => 'tokenizer',
          4 => 'xml',
          5 => 'ctype',
          6 => 'json',
        ),
        'include_composer_extensions' => true,
      ),
      5 => 'BeyondCode\\SelfDiagnosis\\Checks\\StorageDirectoryIsLinked',
    ),
    'environment_checks' => 
    array (
      'development' => 
      array (
        0 => 'BeyondCode\\SelfDiagnosis\\Checks\\ComposerWithDevDependenciesIsUpToDate',
        1 => 'BeyondCode\\SelfDiagnosis\\Checks\\ConfigurationIsNotCached',
        2 => 'BeyondCode\\SelfDiagnosis\\Checks\\RoutesAreNotCached',
      ),
      'production' => 
      array (
        0 => 'BeyondCode\\SelfDiagnosis\\Checks\\ComposerWithoutDevDependenciesIsUpToDate',
        1 => 'BeyondCode\\SelfDiagnosis\\Checks\\ConfigurationIsCached',
        2 => 'BeyondCode\\SelfDiagnosis\\Checks\\DebugModeIsNotEnabled',
        'BeyondCode\\SelfDiagnosis\\Checks\\PhpExtensionsAreDisabled' => 
        array (
          'extensions' => 
          array (
            0 => 'xdebug',
          ),
        ),
        3 => 'BeyondCode\\SelfDiagnosis\\Checks\\RoutesAreCached',
      ),
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => 'mg.sjpanel.com',
      'secret' => 'key-d414464221d7d7d2c932dac2650a08a1',
      'endpoint' => 'api.mailgun.net',
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\Models\\Auth\\User',
      'key' => NULL,
      'secret' => NULL,
      'webhook' => 
      array (
        'secret' => NULL,
        'tolerance' => 300,
      ),
    ),
    'bitbucket' => 
    array (
      'active' => false,
      'client_id' => NULL,
      'client_secret' => NULL,
      'redirect' => NULL,
      'scopes' => 
      array (
      ),
      'with' => 
      array (
      ),
    ),
    'facebook' => 
    array (
      'active' => true,
      'client_id' => '6884413308266531',
      'client_secret' => '67ea3933fe301768a041ad7427aff813',
      'redirect' => 'https://test3.sjpanel.com/login/facebook/callback',
      'scopes' => 
      array (
      ),
      'with' => 
      array (
      ),
      'fields' => 
      array (
      ),
    ),
    'github' => 
    array (
      'active' => false,
      'client_id' => NULL,
      'client_secret' => NULL,
      'redirect' => NULL,
      'scopes' => 
      array (
      ),
      'with' => 
      array (
      ),
    ),
    'google' => 
    array (
      'active' => true,
      'client_id' => '466950265133-h4d31r880qda7noqi5vuu06nnfou2mku.apps.googleusercontent.com',
      'client_secret' => 'T5tXdLB_UgBnyUkb9NyX_xff',
      'redirect' => 'https://test3.sjpanel.com/login/google/callback',
      'scopes' => 
      array (
        0 => 'https://www.googleapis.com/auth/plus.me',
        1 => 'https://www.googleapis.com/auth/plus.profile.emails.read',
      ),
      'with' => 
      array (
      ),
    ),
    'linkedin' => 
    array (
      'active' => true,
      'client_id' => '778pp5ryyhxhtg',
      'client_secret' => 'GJmZvUNKfYGBSFFT',
      'redirect' => 'https://test3.sjpanel.com/login/linkedin/callback',
      'scopes' => 
      array (
      ),
      'with' => 
      array (
      ),
      'fields' => 
      array (
      ),
    ),
    'twitter' => 
    array (
      'active' => true,
      'client_id' => 'ntvkrM7HprLXShM05piK1zhFm',
      'client_secret' => '7BFju0D78vw9GE3Sg6Ri1BEz0AUV0cc5Gfji0Sw4Rb0de8XkQC',
      'redirect' => 'https://test3.sjpanel.com/login/twitter/callback',
      'scopes' => 
      array (
      ),
      'with' => 
      array (
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'redis',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'sj_panel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'settings' => 
  array (
    'store' => 'json',
    'path' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/settings.json',
    'connection' => NULL,
    'table' => 'settings',
    'keyColumn' => 'key',
    'valueColumn' => 'value',
    'RECAPTCHA_SITE_KEY' => '6Lcqcp0UAAAAABYZtVo4ayjR_WEwt_UMcKLpuy76',
    'RECAPTCHA_SECRET_KEY' => '6Lcqcp0UAAAAANmlUp9Oi_8iYYEolxdB0DNOmX2w',
    'APACE' => 
    array (
      'API_URL' => 'http://apace_new.local',
      'API_KEY' => '5F4943277A063EF26D25D7BBC57298FFB2029915',
    ),
  ),
  'translation_sheet' => 
  array (
    'googleApplicationName' => 'Laravel Translation Sheet',
    'serviceAccountEmail' => 'translation-service@sj-panel-live-1532013224820.iam.gserviceaccount.com',
    'serviceAccountCredentialsFile' => 'resources/google/service-account.json',
    'spreadsheetId' => '1KEvHiiCDzXvkSLz4oSq4iuBttfnYXnslm6dJeQAhGyM',
    'locales' => 'en_US,es_US,en_UK,en_CA,fr_CA,en_FR,fr_FR,en_IT,it_IT,en_DE,de_DE,es_ES,en_ES,en_IN,hi_IN,en_AU',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/var/www/html/ramesh/sjpanel.com/public_html/resources/views',
    ),
    'compiled' => '/var/www/html/ramesh/sjpanel.com/public_html/storage/framework/views',
  ),
  'blade-directives' => 
  array (
    'directives' => 
    array (
    ),
  ),
  'cors' => 
  array (
    'supportsCredentials' => false,
    'allowedOrigins' => 
    array (
      0 => '*',
    ),
    'allowedOriginsPatterns' => 
    array (
    ),
    'allowedHeaders' => 
    array (
      0 => '*',
    ),
    'allowedMethods' => 
    array (
      0 => '*',
    ),
    'exposedHeaders' => 
    array (
    ),
    'maxAge' => 0,
  ),
  'debug-server' => 
  array (
    'host' => 'tcp://127.0.0.1:9912',
  ),
  'translatable' => 
  array (
    'locales' => 
    array (
      0 => 'en',
      1 => 'fr',
      'es' => 
      array (
        0 => 'MX',
        1 => 'CO',
      ),
    ),
    'locale_separator' => '-',
    'locale' => NULL,
    'use_fallback' => false,
    'use_property_fallback' => true,
    'fallback_locale' => 'en',
    'translation_model_namespace' => NULL,
    'translation_suffix' => 'Translation',
    'locale_key' => 'locale',
    'to_array_always_loads_translations' => true,
  ),
  'captcha' => 
  array (
    'siteKey' => '6Lcqcp0UAAAAABYZtVo4ayjR_WEwt_UMcKLpuy76',
    'secretKey' => '6Lcqcp0UAAAAANmlUp9Oi_8iYYEolxdB0DNOmX2w',
    'options' => 
    array (
      'hideBadge' => false,
      'dataBadge' => 'bottomright',
      'timeout' => '5',
      'debug' => false,
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'activitylog' => 
  array (
    'enabled' => true,
    'delete_records_older_than_days' => 365,
    'default_log_name' => 'default',
    'default_auth_driver' => NULL,
    'subject_returns_soft_deleted_models' => false,
    'activity_model' => 'Spatie\\Activitylog\\Models\\Activity',
    'table_name' => 'activity_log',
  ),
  'ide-helper' => 
  array (
    'filename' => '_ide_helper',
    'format' => 'php',
    'meta_filename' => '.phpstorm.meta.php',
    'include_fluent' => false,
    'include_factory_builders' => false,
    'write_model_magic_where' => true,
    'write_eloquent_model_mixins' => false,
    'include_helpers' => false,
    'helper_files' => 
    array (
      0 => '/var/www/html/ramesh/sjpanel.com/public_html/vendor/laravel/framework/src/Illuminate/Support/helpers.php',
    ),
    'model_locations' => 
    array (
      0 => 'app',
    ),
    'extra' => 
    array (
      'Eloquent' => 
      array (
        0 => 'Illuminate\\Database\\Eloquent\\Builder',
        1 => 'Illuminate\\Database\\Query\\Builder',
      ),
      'Session' => 
      array (
        0 => 'Illuminate\\Session\\Store',
      ),
    ),
    'magic' => 
    array (
    ),
    'interfaces' => 
    array (
    ),
    'custom_db_types' => 
    array (
    ),
    'model_camel_case_properties' => false,
    'type_overrides' => 
    array (
      'integer' => 'int',
      'boolean' => 'bool',
    ),
    'include_class_docblocks' => false,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
  'bootstrap_form' => 
  array (
    'type' => '',
    'left_column_class' => 'col-sm-2 col-md-3',
    'right_column_class' => 'col-sm-10 col-md-9',
    'left_column_offset_class' => 'col-sm-offset-2 col-md-offset-3',
    'show_all_errors' => false,
    'icon_prefix' => 'fa fa-',
    'error_bag' => 'default',
    'error_class' => 'has-error',
  ),
);
